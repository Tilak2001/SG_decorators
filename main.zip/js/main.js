

   $('.main-content-btn').hover(function(){

    $(this).toggleClass('hover');
   });
   
   $('.contactbtn').hover(function(){
    $(this).toggleClass('hover');
   });
   
   
   $('.social-icons i').hover(function(){
        $(this).toggleClass('hover');
    });

    $('.nav-link').click(function(){
        if($(this).hasClass('active')) return;

        $('.nav-link').removeClass('active')
        $(this).addClass('active');
    });


    $('.playbtn').click(function(){
      $('iframe').attr('src', 'https://www.youtube.com/embed/JEirkz6Cr-0?autoplay=1&rel=0');
      $('.video-clip').addClass('show'); 
      
      
    })


    $('.close-btn').click(function(){
      $('iframe').attr('src', '');
      $('.video-clip').removeClass('show');
    })


  
 
  
        var $wrapper = $('.visions-wrapper');
        var $dots = $('.dot-indicator');
        var totalSlides = $('.visions').length;
        
        function goToSlide(index) {
          var offset = -index * 100;  
          $wrapper.css('transform', 'translateX(' + offset + '%)');
          $dots.removeClass('active');  
          $dots.eq(index).addClass('active'); 
        }
      
       
        $dots.click(function () {
          var slideIndex = $(this).data('slide'); 
          goToSlide(slideIndex);  
        });
      
        
        setInterval(function () {
          var currentIndex = $dots.index($('.dot-indicator.active'));  
          currentIndex = (currentIndex + 1) % totalSlides; 
          goToSlide(currentIndex);  
        }, 5000);  
 
      
      
      



// $(document).ready(function(){

//     $('.dot').click(function(){
        
//         $('#feature-1').fadeIn(250).addClass('active');
//         var featureNumber = $(this).data('feature');
//         console.log(featureNumber);
//         if ($(this).hasClass('active')) {
//             $(this).removeClass('active')
//         };


//         $('.dot').removeClass('active')
//         $(this).addClass('active');

//          $('.slide').fadeOut(10, function() {
        
//             $(this).removeClass('active');

//             $('#feature-' + featureNumber).fadeIn(250).addClass('active');
//         });

//     })

// })


// var interval = window.setInterval(rotateSlides, 3000)
  
// function rotateSlides(){
//   var $firstSlide = $('.carousel').find('div:first');
//   var width = $firstSlide.width();
  
//   $firstSlide.animate({marginLeft: -width}, 1000, function(){
    // What to do after the animation
//   })
// }



//Scroll-spy
    $(window).scroll(function () {
      var scrollPosition = $(window).scrollTop();
      $('.nav-link').each(function () {
        var sectionID = $(this).attr('href');
  
        
        if (sectionID !== "#" && $(sectionID).length) {
          var sectionTop = $(sectionID).offset().top - 120;
          var sectionBottom = sectionTop + $(sectionID).outerHeight();
  
          if (scrollPosition >= sectionTop && scrollPosition < sectionBottom) {
            $('.nav-link').removeClass('active');
            $(this).addClass('active');
          }
        }
      });
    });

  

 

   //animation for the header line
    function isInViewport(element) {
      var elementTop = $(element).offset().top;
      var elementBottom = elementTop + $(element).outerHeight();
      var viewportTop = $(window).scrollTop();
      var viewportBottom = viewportTop + $(window).height();
      
      return (elementBottom > viewportTop && elementTop < viewportBottom);
    }
  

    $(window).on('scroll', function () {
      $('h2.head').each(function () {
    
        if (isInViewport(this)) {
        
          $(this).addClass('animate-line');
        } else {
    
          $(this).removeClass('animate-line');
        }
      });
    });
  
    $('h2.head').each(function () {
      if (isInViewport(this)) {
        $(this).addClass('animate-line');
      }
    });


    $(window).on('scroll', function () {
      $('h2.head-span span').each(function () {
          if (isInViewport(this)) {
              $(this).addClass('animeline');
          } else {
              $(this).removeClass('animeline');
          }
      });
  });

  
  $('h2.head-span span').each(function () {
      if (isInViewport(this)) {
          $(this).addClass('animeline');
      }
  });


  

//animation for footer links
    $('.nav-link-footer').hover(function () {
        $(this).toggleClass('active');
      }
    );

  

 

//animation for objective section
    function isInViewport(element) {
        var elementTop = $(element).offset().top;
        var elementBottom = elementTop + $(element).outerHeight();
        var viewportTop = $(window).scrollTop();
        var viewportBottom = viewportTop + $(window).height();
        
        return (elementBottom > viewportTop && elementTop < viewportBottom);
    }

    $(window).on('scroll', function () {
        $('.objective-text').each(function () {
            if (isInViewport(this)) {
                $(this).addClass('visible');
            } else {
                $(this).removeClass('visible'); 
            }
        });
    });

    $('.objective-text').each(function () {
        if (isInViewport(this)) {
            $(this).addClass('visible');
        }
    });



    //animation for values section

    $(window).on('scroll', function () {
      $('.slide-up, .slide-down').each(function () {
          if (isInViewport(this)) {
              $(this).addClass('visible');
          } else {
              $(this).removeClass('visible'); 
          }
      });
  });

  $('.slide-up, .slide-down').each(function () {
      if (isInViewport(this)) {
          $(this).addClass('visible');
      }
  });
 



//animation for cards
  $(window).on('scroll', function () {
    $('.zoom-out').each(function () {
        if (isInViewport(this)) {
            $(this).addClass('visible');
        } else {
            $(this).removeClass('visible'); 
        }
    });
});

$('.zoom-out').each(function () {
    if (isInViewport(this)) {
        $(this).addClass('visible');
    }
});

